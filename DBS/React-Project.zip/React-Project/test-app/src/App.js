import React, { Component } from "react";
import axios from "axios";
import Layout from "./Components/Layout/Layout";
// import Expenditure from "./Components/Expenditure/Expenditure";
class App extends Component {
  state = {};

  // addBookHandler = () => {
  //   axios
  //     .post("http://localhost:3000/books", this.state.newBookData)
  //     .then(response => {
  //       this.state.books.push(response.data);

  //       this.setState({
  //         newBookModal: false,
  //         newBookData: {
  //           title: "",
  //           rating: ""
  //         }
  //       });
  //     });
  // };

  updateBookHandler = () => {};

  editBookHandler = (id, title, rating) => {
    this.setState({
      editBookData: { id, title, rating },
      editBookModal: !this.state.editBookModal
    });
  };

  toggleEditBookModalOpen = () => {
    this.setState({ editBookModal: true });
  };

  toggleEditBookModalClose = () => {
    this.setState({ editBookModal: false });
  };

  toggleNewBookModalOpen = () => {
    this.setState({ newBookModal: true });
  };

  toggleNewBookModalClose = () => {
    this.setState({ newBookModal: false });
  };

  componentDidMount = () => {
    axios.get("http://localhost:3000/books").then(response => {
      this.setState({ books: response.data });
    });
  };
  render() {
    // let books = this.state.books.map(book => {
    //   return (
    //     <tr key={book.id}>
    //       <td>{book.id}</td>
    //       <td>{book.title}</td>
    //       <td>{book.rating}</td>
    //       <td>
    //         <Button
    //           color="success"
    //           size="sm"
    //           className="mr-2"
    //           onClick={this.toggleEditBookModalOpen}
    //         >
    //           Edit
    //         </Button>
    //         <Button color="danger" size="sm">
    //           Delete
    //         </Button>
    //       </td>
    //     </tr>
    //   );
    // });
    return (
      <div className="App container">
        <Layout />
        {/* <ToolBar />
        <Button color="primary" onClick={this.toggleNewBookModalOpen}>
          Add Book
        </Button>
        <Modal
          isOpen={this.state.newBookModal}
          toggle={this.toggleNewBookModal}
        >
          <ModalHeader toggle={this.toggleNewBookModal}>Add Book</ModalHeader>
          <ModalBody>
            <InputGroup>
              <InputGroupAddon addonType="prepend">
                <InputGroupText>Title</InputGroupText>
              </InputGroupAddon>
              <Input
                id="title"
                value={this.state.newBookData.title}
                onChange={e => {
                  let newBookData = this.state.newBookData;
                  newBookData.title = e.target.value;
                  this.setState({ newBookData });
                }}
              />
            </InputGroup>
            <InputGroup>
              <InputGroupAddon addonType="prepend">
                <InputGroupText>Rating</InputGroupText>
              </InputGroupAddon>
              <Input
                id="rating"
                value={this.state.newBookData.rating}
                onChange={e => {
                  let newBookData = this.state.newBookData;
                  newBookData.rating = e.target.value;
                  this.setState({ newBookData });
                }}
              />
            </InputGroup>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.addBookHandler}>
              Add
            </Button>{" "}
            <Button color="secondary" onClick={this.toggleNewBookModalClose}>
              Cancel
            </Button>
          </ModalFooter>
        </Modal>

        <Modal
          isOpen={this.state.editBookModal}
          toggle={this.toggleEditBookModal}
        >
          <ModalHeader toggle={this.toggleEditBookModal}>
            Edit a Book
          </ModalHeader>
          <ModalBody>
            <InputGroup>
              <InputGroupAddon addonType="prepend">
                <InputGroupText>Title</InputGroupText>
              </InputGroupAddon>
              <Input
                id="title"
                value={this.state.editBookData.title}
                onChange={e => {
                  let editBookData = this.state.editBookData;
                  editBookData.title = e.target.value;
                  this.setState({ editBookData });
                }}
              />
            </InputGroup>
            <InputGroup>
              <InputGroupAddon addonType="prepend">
                <InputGroupText>Rating</InputGroupText>
              </InputGroupAddon>
              <Input
                id="rating"
                value={this.state.editBookData.rating}
                onChange={e => {
                  let editBookData = this.state.editBookData;
                  editBookData.rating = e.target.value;
                  this.setState({ editBookData });
                }}
              />
            </InputGroup>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.updateBookHandler}>
              Update Book
            </Button>{" "}
            <Button color="secondary" onClick={this.toggleEditBookModalClose}>
              Cancel
            </Button>
          </ModalFooter>
        </Modal>

        <Table>
          <thead>
            <tr>
              <th>#</th>
              <th>Title</th>
              <th>Rating</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody></tbody>
        </Table> */}
      </div>
    );
  }
}

export default App;
