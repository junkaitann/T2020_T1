// import React from "react";
// import AccountBalanceChart from "./AccountBalanceChart";
// import Aux from "../../hoc/Aux";

// const accountBalance = () => (
//   <Aux>
//     <div>Total Balance: $10000</div>
//     <div>
//       <AccountBalanceChart />
//     </div>
//     ;
//   </Aux>
// );
// export default accountBalance;

import React, { Component } from "react";
import classes from "./AccountBalance.module.css";
import AccountBalanceChart from "./AccountBalanceChart";
import Aux from "../../hoc/Aux";

class AccountBalance extends Component {
  state = {};
  render() {
    return (
      <Aux>
        <div>
          <thead className={classes.AccountBalance}>
            {/* <tr>
            <th>Date</th>
            <th>Amount Spent</th>
          </tr> */}

            <AccountBalanceChart />
          </thead>
          {/* <tbody></tbody> */}
        </div>
      </Aux>
    );
  }
}

export default AccountBalance;
