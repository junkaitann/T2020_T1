// var React = require("react");
// var Component = React.Component;
// var CanvasJSReact = require("./canvasjs.react");
// var CanvasJS = CanvasJSReact.CanvasJS;
// var CanvasJSChart = CanvasJSReact.CanvasJSChart;

import React, { Component } from "react";
import { Bar } from "react-chartjs-2";

class AccountBalanceChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      chartData: {
        labels: ["September", "October", "November"],
        datasets: [
          {
            label: "Account Savings",
            data: [10889.98, 11046.56, 11239.57],
            backgroundColor: [
              "rgba(255,99,132,0.6)",
              "rgba(54,162,235,0.6)",
              "rgba(255,206,86,0.6)"
            ]
          }
        ]
      }
    };
  }

  render() {
    return (
      <div className="chart">
        <Bar
          data={this.state.chartData}
          width={500}
          height={300}
          options={{ maintainAspecRatio: false }}
        />
      </div>
    );
  }
}

export default AccountBalanceChart;
