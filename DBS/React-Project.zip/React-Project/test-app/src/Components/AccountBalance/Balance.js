import React from "react";

const balance = () => <div>Total Account Balance: $1000</div>;

export default balance;
