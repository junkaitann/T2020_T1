import React, { Component } from "react";
import classes from "./Expenditure.module.css";
import ExpenditureChart from "./ExpenditureChart/ExpenditureChart";
import Aux from "../../hoc/Aux";

class Expenditure extends Component {
  state = {};
  render() {
    return (
      <Aux>
        <div>
          <thead className={classes.Expenditure}>
            {/* <tr>
            <th>Date</th>
            <th>Amount Spent</th>
          </tr> */}

            <ExpenditureChart />
          </thead>
          {/* <tbody></tbody> */}
        </div>
      </Aux>
    );
  }
}

export default Expenditure;
