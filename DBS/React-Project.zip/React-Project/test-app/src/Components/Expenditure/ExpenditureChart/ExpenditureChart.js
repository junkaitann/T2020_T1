// var React = require("react");
// var Component = React.Component;
// var CanvasJSReact = require("./canvasjs.react");
// var CanvasJS = CanvasJSReact.CanvasJS;
// var CanvasJSChart = CanvasJSReact.CanvasJSChart;

import React, { Component } from "react";
import { Bar } from "react-chartjs-2";

class ExpenditureChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      chartData: {
        labels: ["September", "October", "November"],
        datasets: [
          {
            label: "Expenditure",
            data: [3627.8, 4568.07, 4157.78],
            backgroundColor: [
              "rgba(255,99,132,0.6)",
              "rgba(54,162,235,0.6)",
              "rgba(255,206,86,0.6)"
            ]
          }
        ]
      }
    };
  }

  render() {
    return (
      <div className="chart">
        <Bar
          data={this.state.chartData}
          width={500}
          height={300}
          options={{ maintainAspectRatio: false }}
        />
      </div>
    );
  }
}

export default ExpenditureChart;
