import React, { Component } from "react";
import Aux from "../../hoc/Aux.js";
import classes from "./Layout.module.css";
import ToolBar from "../../Navigation/ToolBar/ToolBar";
// import {
//   Table,
//   Button,
//   Modal,
//   ModalFooter,
//   ModalBody,
//   ModalHeader,
//   InputGroup,
//   InputGroupAddon,
//   InputGroupText,
//   Input
// } from "reactstrap";
// import ExpenditureChart from "../Expenditure/ExpenditureChart";
import Expenditure from "../Expenditure/Expenditure";
import WelcomeMessage from "../WelcomeMessage/WelcomeMessage";
import TotalExpenditure from "../TotalExpenditure/TotalExpenditure";
import AccountBalance from "../AccountBalance/AccountBalance";
import Balance from "../AccountBalance/Balance";
import ProductSuggestion from "../ProductSuggestion/ProductSuggestion";
import Person from "../Person/Person";

class Layout extends Component {
  state = {
    user: "Mary Tan",
    customerId: "2",
    riskLevel: "High",
    accountId: "79",

    showSideDraw: false
  };

  render() {
    return (
      <Aux>
        <ToolBar />
        <div className={classes.Layout}>
          {/* <div>
            <WelcomeMessage />
          </div>
          <div className={classes.ProductSuggestionShift}>
            <ProductSuggestion />
          </div>
          <div className={classes.GraphShift}>
            <TotalExpenditure /> */}
          {/* </div>
          <div> */}
          {/* <Expenditure /> */}
          {/* </div>
          <div> */}
          {/* </div>
          <div> */}
          {/* <AccountBalance /> */}
          {/* </div>
          <main>{this.props.children}</main> */}
          <Person />
        </div>
      </Aux>
    );
  }
}

export default Layout;
