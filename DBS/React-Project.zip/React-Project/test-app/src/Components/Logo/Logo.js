import React from "react";
import dbsLogo from "../../assets/images/DBS-Logo-1.png";
import classes from "./Logo.module.css";

const logo = props => (
  <div className={classes.Logo}>
    <img src={dbsLogo} alt="DBS" width="150" />
  </div>
);

export default logo;
