import React, { Component } from "react";
import Expenditure from "../Expenditure/Expenditure";
import WelcomeMessage from "../WelcomeMessage/WelcomeMessage";
import TotalExpenditure1 from "../TotalExpenditure/TotalExpenditure";
import AccountBalance1 from "../AccountBalance/AccountBalance";
// import Balance from "../AccountBalance/Balance";
import ProductSuggestion from "../ProductSuggestion/ProductSuggestion";
import Aux from "../../hoc/Aux";
import classes from "../Layout/Layout.module.css";

class Person1 extends Component {
  render() {
    return (
      <Aux>
        <div className={classes.Layout}>
          <div>
            <WelcomeMessage />
          </div>
          <div className={classes.ProductSuggestionShift}>
            <ProductSuggestion />
          </div>
          <div className={classes.GraphShift}>
            <TotalExpenditure1 />
            <Expenditure />
            <AccountBalance1 />
          </div>
        </div>
      </Aux>
    );
  }
}

export default Person1;
