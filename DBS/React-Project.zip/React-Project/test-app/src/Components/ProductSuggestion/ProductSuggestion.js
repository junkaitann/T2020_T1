import React from "react";
import { Jumbotron, Button } from "reactstrap";
import classes from "./ProductSuggestion.module.css";

const productSuggestion = props => {
  return (
    <div className={classes.ProductSuggestionLayout}>
      <Jumbotron>
        <h1 className="display-3">Want More Money ?</h1>
        <p className="lead">Try Our Savings Account Today!</p>
        <hr className="my-2" />
        <p className="lead">
          <Button color="primary">Save Now!</Button>
        </p>
      </Jumbotron>
    </div>
  );
};

export default productSuggestion;
