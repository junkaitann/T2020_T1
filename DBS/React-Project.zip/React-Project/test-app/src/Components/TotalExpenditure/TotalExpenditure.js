import React from "react";

const totalExpenditure = props => (
  <div>Total Expenditure for Past 3 Months: $ 12,353.65</div>
);

export default totalExpenditure;
