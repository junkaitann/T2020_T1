import React from "react";
import { Jumbotron, Button } from "reactstrap";

const welcomeMessage = props => {
  return (
    <div>
      <Jumbotron>
        <h1 className="display-3">Welcome Back, Mary!</h1>
        <p className="lead">We hope you've been saving well!</p>
        <hr className="my-2" />
        {/* <p className="lead">
          <Button color="primary">Learn More</Button>
        </p> */}
      </Jumbotron>
    </div>
  );
};

export default welcomeMessage;
