import React from "react";
import classes from "./ToolBar.module.css";
import Logo from "../../Components/Logo/Logo";
import { Button } from "reactstrap";
// import ProductSuggestion from "../../Components/ProductSuggestion/ProductSuggestion";

const toolbar = props => (
  <header className={classes.Toolbar}>
    <div className={classes.Logo}>
      <Logo />
    </div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <Button> Savings Report</Button>
    <Button>Full Expenditure Report</Button>
  </header>
);

export default toolbar;
